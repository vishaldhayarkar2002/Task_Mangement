# Copyright (c) 2025, vishal and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestCustomerGRN(FrappeTestCase):
	pass
